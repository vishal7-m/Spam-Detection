#!/usr/bin/env python
# coding: utf-8

# #project------------------------SPAM DETECTION MODEL----------------------------------------

# In[1]:


import pandas as pd
import numpy as np
import nltk
import string
from sklearn.linear_model import LogisticRegression
import warnings
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report,roc_curve,auc,precision_recall_curve
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer,TfidfVectorizer
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import re


# In[2]:


df = pd.read_csv(r"C:\Users\visha\Downloads\sms+spam+collection\SMSSpamCollection", sep='\t', names=["label","msg"])
df.head()


# In[3]:


#preprocessing

stop_words = set(stopwords.words('english'))
stemmer = PorterStemmer()



# In[4]:


#text vecotization
cv=CountVectorizer(max_features=3000)

x=cv.fit_transform(df['msg']).toarray()
y=df['label'].map({'ham':0,'spam':1})


# In[ ]:


#Train split---------------------------------------------------


# In[5]:


x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=42)


# In[ ]:


#model prediction---------------------------------------------------------------------------------------------


# In[6]:


model=MultinomialNB()
model.fit(x_train,y_train)
y_pred=model.predict(x_test)


# In[ ]:


#Evaluate Model-----------------------------------------------------------------------------------------------


# In[7]:


print("Accuracy: ",accuracy_score(y_test,y_pred)*100)
report=classification_report(y_test,y_pred,target_names=['ham','spam'],output_dict=True)


# In[8]:


ddf=pd.DataFrame(report).transpose()
print(ddf)


# In[9]:


sns.heatmap(ddf.iloc[:-1,:].T,annot=True,cmap="Blues")
plt.show()


# In[ ]:


#Confusion matrix---------------------------------------------------------------------------------------------


# In[10]:


cm=confusion_matrix(y_test,y_pred)
sns.heatmap(cm,annot=True,fmt="d",cmap="Greens",xticklabels=['Ham','Spam'],yticklabels=['Ham','Spam'])
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()


# In[ ]:


#Roc curves---------------------------------------------------------------------------------------------------


# In[11]:


y_pred_prob=model.predict_proba(x_test)[:,1]
fpr,tpr,_=roc_curve(y_test,y_pred_prob)
roc_auc=auc(fpr,tpr)
                                            


# In[12]:


plt.plot(fpr,tpr,label=f'AUC={roc_auc:.2f}')
plt.plot([0,1],[0,1],'--')
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC CURVES") 
plt.legend()
plt.show()


# In[ ]:


#Precision Recall Curve---------------------------------------------------------------------------------------


# In[13]:


precision,recall,_=precision_recall_curve(y_test,y_pred_prob)
plt.plot(recall,precision,marker='.')
plt.xlabel("Recall")
plt.ylabel("Precision Recall Curve")
plt.title("Precision_Recall_Curve")
plt.show()


# In[14]:


print(df.columns)



# In[15]:


spam_words = " ".join(df[df['label']=='spam']['msg'])
ham_words = " ".join(df[df['label']=='ham']['msg'])

spam_wc = WordCloud(width=600, height=400, background_color="black").generate(spam_words)
ham_wc = WordCloud(width=600, height=400, background_color="white").generate(ham_words)

plt.imshow(spam_wc); 
plt.axis("off");
plt.title("Spam Word Cloud");
plt.show()
plt.imshow(ham_wc);
plt.axis("off");
plt.title("Ham Word Cloud");
plt.show()


# In[ ]:


#cleaning message---------------------------------------------------------------------------------------------


# In[16]:


def cleantext(text):
    text = text.lower()
    text = re.sub(r'[^a-z\s]', '', text)
    tokens = text.split()
    tokens = [stemmer.stem(word) for word in tokens if word not in stop_words]
    return ' '.join(tokens)
df['Cleaned Message']=df['msg'].apply(cleantext)
df.head(20)

